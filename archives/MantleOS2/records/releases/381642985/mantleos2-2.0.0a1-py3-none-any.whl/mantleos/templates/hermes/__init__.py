"""Hermes reference assimilation template."""

