"""Packaged public construction templates."""

