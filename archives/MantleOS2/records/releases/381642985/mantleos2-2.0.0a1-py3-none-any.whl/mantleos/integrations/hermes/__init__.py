"""Hermes reference integration resources."""

