# Apply the Hermes reference seed

Start from the exact commit recorded in `mantle/ASSIMILATION.json`. Copy `mantle/` into the NEST, then run `git apply --check host-edge.patch` and `git apply host-edge.patch`. Verify with MantleOS before any birth.

To reverse the public delta before birth, run `git apply -R host-edge.patch` and remove only the copied `mantle/` directory. Private organism state is not part of this bundle.
